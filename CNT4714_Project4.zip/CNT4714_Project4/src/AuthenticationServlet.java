/* Name: Michael Torres
Course: CNT 4714 – Spring 2026 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: April 27, 2026
*/
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class AuthenticationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String usernameEntered = request.getParameter("username");
        String passwordEntered = request.getParameter("password");

        // Load the systemapp properties to connect to credentialsDB
        Properties properties = new Properties();
        String propertiesPath = getServletContext().getRealPath("/WEB-INF/conf/systemapp.properties");
        
        try (FileInputStream fis = new FileInputStream(propertiesPath)) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServletException("Failed to load database properties.");
        }

        String dbUrl = properties.getProperty("MYSQL_DB_URL");
        String dbUser = properties.getProperty("MYSQL_DB_USERNAME");
        String dbPass = properties.getProperty("MYSQL_DB_PASSWORD");

        boolean isValidUser = false;

        try {
            // Load the MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to credentialsDB and validate
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
                String sql = "SELECT * FROM usercredentials WHERE login_username = ? AND login_password = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, usernameEntered);
                    pstmt.setString(2, passwordEntered);
                    
                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            isValidUser = true;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Database connection error.", e);
        }

        // Routing logic based on authentication success or failure
        if (isValidUser) {
            // Create a session to store the username for the dashboards
            HttpSession session = request.getSession();
            session.setAttribute("currentUser", usernameEntered);

            // Redirect based on the username
            String redirectUrl = "";
            switch (usernameEntered) {
                case "root":
                    redirectUrl = "/Front-End-Pages/rootHome.jsp";
                    break;
                case "client":
                    redirectUrl = "/Front-End-Pages/clientHome.jsp";
                    break;
                case "dataentry":
                    redirectUrl = "/Front-End-Pages/dataEntryHome.jsp";
                    break;
                case "theaccountant":
                    redirectUrl = "/Front-End-Pages/accountantHome.jsp";
                    break;
                default:
                    redirectUrl = "/Front-End-Pages/errorpage.html";
            }
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(redirectUrl);
            dispatcher.forward(request, response);

        } else {
            // Authentication failed
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Front-End-Pages/errorpage.html");
            dispatcher.forward(request, response);
        }
    }
}