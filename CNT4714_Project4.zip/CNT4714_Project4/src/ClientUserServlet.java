/* Name: Michael Torres
Course: CNT 4714 – Spring 2026 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: April 27, 2026
*/
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class ClientUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 1. Verify Authentication (Must be 'client')
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null || !session.getAttribute("currentUser").equals("client")) {
            response.sendRedirect(request.getContextPath() + "/Front-End-Pages/errorpage.html");
            return;
        }

        String sqlStatement = request.getParameter("sqlStatement");
        if (sqlStatement != null) sqlStatement = sqlStatement.trim();
        String sqlResult = "";

        // 2. Load Client Properties
        Properties properties = new Properties();
        String propertiesPath = getServletContext().getRealPath("/WEB-INF/conf/client.properties");

        try (FileInputStream fis = new FileInputStream(propertiesPath)) {
            properties.load(fis);
        } catch (IOException e) {
            sqlResult = "<div style='color:red;'>Error loading database properties.</div>";
        }

        // 3. Connect and Execute
        if (sqlStatement != null && !sqlStatement.isEmpty() && sqlResult.isEmpty()) {
            String dbUrl = properties.getProperty("MYSQL_DB_URL");
            String dbUser = properties.getProperty("MYSQL_DB_USERNAME");
            String dbPass = properties.getProperty("MYSQL_DB_PASSWORD");

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                     Statement stmt = conn.createStatement()) {

                    String queryType = sqlStatement.substring(0, 6).toLowerCase();

                    if (queryType.equals("select")) {
                        try (ResultSet rs = stmt.executeQuery(sqlStatement)) {
                            sqlResult = buildHtmlTableFromResult(rs);
                        }
                    } else {
                        // The client user only has SELECT privileges. If they try an UPDATE/INSERT,
                        // MariaDB will block it and throw an SQLException, which we catch below.
                        int rowsAffected = stmt.executeUpdate(sqlStatement);
                        sqlResult = "<div style='background-color: #00FF00; color: black; padding: 10px; font-weight: bold;'>" +
                                "The statement executed successfully.<br>" + rowsAffected + " row(s) affected.<br>" +
                                "Business Logic Not Triggered!</div>";
                    }
                }
            } catch (SQLException e) {
                sqlResult = "<div style='color:white; font-weight:bold;'>Error executing the SQL statement:<br>" + e.getMessage() + "</div>";
            } catch (Exception e) {
                sqlResult = "<div style='color:red; font-weight:bold;'>System Error: " + e.getMessage() + "</div>";
            }
        }

        // 4. Return Results
        request.setAttribute("sqlResult", sqlResult);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Front-End-Pages/clientHome.jsp");
        dispatcher.forward(request, response);
    }

    // Identical helper method from RootUserServlet
    private String buildHtmlTableFromResult(ResultSet rs) throws SQLException {
        StringBuilder html = new StringBuilder();
        html.append("<table style='width: 100%; border-collapse: collapse; margin-top: 10px;'>");
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount();

        html.append("<tr style='background-color: red; color: black; font-weight: bold;'>");
        for (int i = 1; i <= columnCount; i++) {
            html.append("<th style='border: 1px solid white; padding: 5px;'>").append(rsmd.getColumnName(i)).append("</th>");
        }
        html.append("</tr>");

        boolean alternateColor = false;
        while (rs.next()) {
            String bgColor = alternateColor ? "#cccccc" : "#ffffff";
            html.append("<tr style='background-color: ").append(bgColor).append("; color: black;'>");
            for (int i = 1; i <= columnCount; i++) {
                html.append("<td style='border: 1px solid white; padding: 5px; text-align: center;'>").append(rs.getString(i)).append("</td>");
            }
            html.append("</tr>");
            alternateColor = !alternateColor;
        }
        html.append("</table>");
        return html.toString();
    }
}
