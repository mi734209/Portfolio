/* Name: Michael Torres
Course: CNT 4714 – Spring 2026 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: April 27, 2026
*/
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class DataEntryServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 1. Verify Authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null || !session.getAttribute("currentUser").equals("dataentry")) {
            response.sendRedirect(request.getContextPath() + "/Front-End-Pages/errorpage.html");
            return;
        }

        String formType = request.getParameter("formType");
        String sqlResult = "";

        // 2. Load Data Entry Properties
        Properties properties = new Properties();
        String propertiesPath = getServletContext().getRealPath("/WEB-INF/conf/dataentry.properties");

        try (FileInputStream fis = new FileInputStream(propertiesPath)) {
            properties.load(fis);
        } catch (IOException e) {
            sqlResult = "<div style='color:red;'>Error loading database properties.</div>";
        }

        // 3. Connect and Execute Prepared Statements
        if (formType != null && sqlResult.isEmpty()) {
            String dbUrl = properties.getProperty("MYSQL_DB_URL");
            String dbUser = properties.getProperty("MYSQL_DB_USERNAME");
            String dbPass = properties.getProperty("MYSQL_DB_PASSWORD");

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {

                    String message = "";
                    PreparedStatement pstmt = null;

                    // Route based on which form was submitted
                    switch (formType) {
                        case "supplier":
                            pstmt = conn.prepareStatement("INSERT INTO suppliers VALUES (?, ?, ?, ?)");
                            pstmt.setString(1, request.getParameter("snum"));
                            pstmt.setString(2, request.getParameter("sname"));
                            pstmt.setInt(3, Integer.parseInt(request.getParameter("status")));
                            pstmt.setString(4, request.getParameter("city"));
                            pstmt.executeUpdate();
                            message = "New suppliers record: (" + request.getParameter("snum") + ", " +
                                    request.getParameter("sname") + ", " + request.getParameter("status") + ", " +
                                    request.getParameter("city") + ") - successfully entered into database.";
                            break;

                        case "part":
                            pstmt = conn.prepareStatement("INSERT INTO parts VALUES (?, ?, ?, ?, ?)");
                            pstmt.setString(1, request.getParameter("pnum"));
                            pstmt.setString(2, request.getParameter("pname"));
                            pstmt.setString(3, request.getParameter("color"));
                            pstmt.setInt(4, Integer.parseInt(request.getParameter("weight")));
                            pstmt.setString(5, request.getParameter("city"));
                            pstmt.executeUpdate();
                            message = "New parts record: (" + request.getParameter("pnum") + ", " +
                                    request.getParameter("pname") + ", " + request.getParameter("color") + ", " +
                                    request.getParameter("weight") + ", " + request.getParameter("city") + ") - successfully entered into database.";
                            break;

                        case "job":
                            pstmt = conn.prepareStatement("INSERT INTO jobs VALUES (?, ?, ?, ?)");
                            pstmt.setString(1, request.getParameter("jnum"));
                            pstmt.setString(2, request.getParameter("jname"));
                            pstmt.setInt(3, Integer.parseInt(request.getParameter("numworkers")));
                            pstmt.setString(4, request.getParameter("city"));
                            pstmt.executeUpdate();
                            message = "New jobs record: (" + request.getParameter("jnum") + ", " +
                                    request.getParameter("jname") + ", " + request.getParameter("numworkers") + ", " +
                                    request.getParameter("city") + ") - successfully entered into database.";
                            break;

                        case "shipment":
                            String snum = request.getParameter("snum");
                            String pnum = request.getParameter("pnum");
                            String jnum = request.getParameter("jnum");
                            int quantity = Integer.parseInt(request.getParameter("quantity"));

                            pstmt = conn.prepareStatement("INSERT INTO shipments VALUES (?, ?, ?, ?)");
                            pstmt.setString(1, snum);
                            pstmt.setString(2, pnum);
                            pstmt.setString(3, jnum);
                            pstmt.setInt(4, quantity);
                            pstmt.executeUpdate();

                            message = "New shipments record: (" + snum + ", " + pnum + ", " + jnum + ", " + quantity + ") - successfully entered into database.";

                            // --- BONUS BUSINESS LOGIC (Form-Based Approach) ---
                            if (quantity >= 100) {
                                // Since we are doing a direct insert, we know exactly which supplier needs the +5 status
                                try (PreparedStatement logicStmt = conn.prepareStatement("UPDATE suppliers SET status = status + 5 WHERE snum = ?")) {
                                    logicStmt.setString(1, snum);
                                    logicStmt.executeUpdate();
                                    message += " Business logic triggered.";
                                }
                            } else {
                                message += " Business logic not triggered.";
                            }
                            break;
                    }

                    if (pstmt != null) pstmt.close();

                    sqlResult = "<div style='background-color: blue; color: white; border: 2px solid yellow; padding: 10px; font-weight: bold; width: 80%; margin: 0 auto;'>" + message + "</div>";

                }
            } catch (SQLException e) {
                // If they enter a duplicate primary key or violate a foreign key, catch it here
                sqlResult = "<div style='background-color: red; color: white; border: 2px solid white; padding: 10px; font-weight: bold; width: 80%; margin: 0 auto;'>" +
                        "Error executing the SQL statement:<br>" + e.getMessage() + "</div>";
            } catch (NumberFormatException e) {
                sqlResult = "<div style='background-color: red; color: white; border: 2px solid white; padding: 10px; font-weight: bold; width: 80%; margin: 0 auto;'>" +
                        "Data Entry Error: Please ensure numeric fields (status, weight, numworkers, quantity) only contain numbers.</div>";
            } catch (Exception e) {
                sqlResult = "<div style='color:red; font-weight:bold;'>System Error: " + e.getMessage() + "</div>";
            }
        }

        // 4. Return Results
        request.setAttribute("sqlResult", sqlResult);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Front-End-Pages/dataEntryHome.jsp");
        dispatcher.forward(request, response);
    }
}