/* Name: Michael Torres
Course: CNT 4714 – Spring 2026 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: April 27, 2026
*/
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class RootUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 1. Verify Authentication (Security Check)
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null || !session.getAttribute("currentUser").equals("root")) {
            response.sendRedirect(request.getContextPath() + "/Front-End-Pages/errorpage.html");
            return;
        }

        // 2. Grab the SQL command from the form
        String sqlStatement = request.getParameter("sqlStatement");
        if (sqlStatement != null) {
            sqlStatement = sqlStatement.trim();
        }

        String sqlResult = ""; // This will hold the HTML table or status message we send back

        // 3. Load the Root User Database Properties
        Properties properties = new Properties();
        String propertiesPath = getServletContext().getRealPath("/WEB-INF/conf/root.properties");

        try (FileInputStream fis = new FileInputStream(propertiesPath)) {
            properties.load(fis);
        } catch (IOException e) {
            sqlResult = "<div style='color:red;'>Error loading database properties.</div>";
        }

        // 4. Connect to the Database and Execute
        if (sqlStatement != null && !sqlStatement.isEmpty() && sqlResult.isEmpty()) {

            String dbUrl = properties.getProperty("MYSQL_DB_URL");
            String dbUser = properties.getProperty("MYSQL_DB_USERNAME");
            String dbPass = properties.getProperty("MYSQL_DB_PASSWORD");

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                     Statement stmt = conn.createStatement()) {

                    // Determine if it's a SELECT query or an UPDATE/INSERT/DELETE
                    String queryType = sqlStatement.substring(0, 6).toLowerCase();

                    if (queryType.equals("select")) {
                        // Handle SELECT queries
                        try (ResultSet rs = stmt.executeQuery(sqlStatement)) {
                            sqlResult = buildHtmlTableFromResult(rs);
                        }
                    } else {
                        // Handle UPDATE, INSERT, DELETE, REPLACE
                        boolean isShipmentUpdate = sqlStatement.toLowerCase().contains("shipments") &&
                                (sqlStatement.toLowerCase().startsWith("insert") ||
                                        sqlStatement.toLowerCase().startsWith("update") ||
                                        sqlStatement.toLowerCase().startsWith("replace"));

                        // 1. BONUS LOGIC PRE-CHECK: Save the state of shipments BEFORE the user's command
                        if (isShipmentUpdate) {
                            stmt.executeUpdate("CREATE TEMPORARY TABLE before_shipments AS SELECT * FROM shipments");
                        }

                        // 2. Execute the user's actual command
                        int rowsAffected = stmt.executeUpdate(sqlStatement);

                        StringBuilder resultBuilder = new StringBuilder();
                        resultBuilder.append("<div style='background-color: #00FF00; color: black; padding: 10px; font-weight: bold;'>");
                        resultBuilder.append("The statement executed successfully.<br>");
                        resultBuilder.append(rowsAffected).append(" row(s) affected.<br>");

                        // 3. BONUS LOGIC POST-CHECK: Find exactly who was affected
                        if (isShipmentUpdate) {
                            // Compare the new state to the temporary table.
                            // We only want suppliers where the row is new OR the quantity changed, AND the new quantity >= 100
                            String findAffectedSuppliers = "SELECT DISTINCT s.snum FROM shipments s " +
                                    "LEFT JOIN before_shipments b " +
                                    "ON s.snum = b.snum AND s.pnum = b.pnum AND s.jnum = b.jnum " +
                                    "WHERE s.quantity >= 100 AND (b.quantity IS NULL OR s.quantity != b.quantity)";

                            int suppliersUpdated = 0;

                            try (ResultSet rsLogic = stmt.executeQuery(findAffectedSuppliers)) {
                                StringBuilder snumList = new StringBuilder();
                                while (rsLogic.next()) {
                                    if (snumList.length() > 0) snumList.append(",");
                                    snumList.append("'").append(rsLogic.getString("snum")).append("'");
                                }

                                // If we found affected suppliers, update their status by 5
                                if (snumList.length() > 0) {
                                    String updateSuppliers = "UPDATE suppliers SET status = status + 5 WHERE snum IN (" + snumList.toString() + ")";
                                    suppliersUpdated = stmt.executeUpdate(updateSuppliers);
                                }
                            }

                            // Clean up the temporary table so it's ready for the next command
                            stmt.executeUpdate("DROP TEMPORARY TABLE before_shipments");

                            resultBuilder.append("Business Logic Detected! - Updating Supplier Status<br>");
                            resultBuilder.append("Business Logic updated ").append(suppliersUpdated).append(" supplier status marks.");
                        } else {
                            resultBuilder.append("Business Logic Not Triggered!");
                        }

                        resultBuilder.append("</div>");
                        sqlResult = resultBuilder.toString();
                    }

                }
            } catch (SQLException e) {
                // Catch standard SQL syntax errors (like selecting from a table that doesn't exist)
                sqlResult = "<div style='color:red; font-weight:bold;'>Error executing the SQL statement:<br>" + e.getMessage() + "</div>";
            } catch (Exception e) {
                sqlResult = "<div style='color:red; font-weight:bold;'>System Error: " + e.getMessage() + "</div>";
            }
        }

        // 5. Send the result back to the JSP
        request.setAttribute("sqlResult", sqlResult);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Front-End-Pages/rootHome.jsp");
        dispatcher.forward(request, response);
    }

    // Helper method to turn a ResultSet into an HTML Table
    private String buildHtmlTableFromResult(ResultSet rs) throws SQLException {
        StringBuilder html = new StringBuilder();
        html.append("<table style='width: 100%; border-collapse: collapse; margin-top: 10px;'>");

        ResultSetMetaData rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount();

        // Build Table Headers
        html.append("<tr style='background-color: red; color: black; font-weight: bold;'>");
        for (int i = 1; i <= columnCount; i++) {
            html.append("<th style='border: 1px solid white; padding: 5px;'>").append(rsmd.getColumnName(i)).append("</th>");
        }
        html.append("</tr>");

        // Build Table Rows
        boolean alternateColor = false;
        while (rs.next()) {
            String bgColor = alternateColor ? "#cccccc" : "#ffffff";
            html.append("<tr style='background-color: ").append(bgColor).append("; color: black;'>");
            for (int i = 1; i <= columnCount; i++) {
                html.append("<td style='border: 1px solid white; padding: 5px; text-align: center;'>").append(rs.getString(i)).append("</td>");
            }
            html.append("</tr>");
            alternateColor = !alternateColor;
        }

        html.append("</table>");
        return html.toString();
    }
}