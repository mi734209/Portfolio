<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Root User App</title>
    <style>
        body { background-color: black; color: white; font-family: sans-serif; text-align: center; }
        .header-green { color: #00FF00; font-size: 2em; margin-bottom: 10px; }
        .header-orange { color: #FFA500; font-size: 1.5em; margin-bottom: 30px; }
        .user-status { color: white; font-size: 1em; margin-bottom: 20px; }
        .root-text { color: #00FF00; font-weight: bold; }
        textarea { 
            width: 80%; 
            height: 200px; 
            background-color: blue; 
            color: white; 
            font-family: monospace; 
            font-size: 1.2em; 
            padding: 10px;
            margin-bottom: 15px;
        }
        .btn { padding: 5px 15px; font-weight: bold; margin: 0 10px; cursor: pointer; }
        .btn-execute { background-color: #00FF00; color: black; }
        .btn-reset { background-color: #FF0000; color: yellow; }
        .btn-clear { background-color: #FFFF00; color: black; }
        .results-section { margin-top: 30px; border-top: 1px solid white; padding-top: 20px; }
    </style>
    <script>
        // Simple JavaScript to clear the results area without reloading the server
        function clearResults() {
            document.getElementById('executionResults').innerHTML = '';
        }
    </script>
</head>
<body>

    <h1 class="header-green">Welcome to the Spring 2026 Project 4 Enterprise System</h1>
    <h2 class="header-orange">A Servlet/JSP-based Multi-tiered Enterprise Application Using A Tomcat Container</h2>

    <hr style="width: 90%; border-color: white;">

    <div class="user-status">
        You are connected to the Project 4 Enterprise System database as a <span class="root-text">root-level</span> user.<br>
        Please enter any SQL query or update command in the box below.
    </div>

    <form action="${pageContext.request.contextPath}/RootUserServlet" method="POST">
        <textarea name="sqlStatement" required>${param.sqlStatement}</textarea>
        <br>
        <input type="submit" value="Execute Command" class="btn btn-execute">
        <input type="button" value="Reset Form" class="btn btn-reset" onclick="this.form.sqlStatement.value='';">
        <input type="button" value="Clear Results" class="btn btn-clear" onclick="clearResults()">
    </form>

    <div class="results-section">
        <p>All execution results will appear below this line.</p>
        <h3>Execution Results:</h3>
        
        <div id="executionResults">
            ${sqlResult}
        </div>
    </div>

</body>
</html>