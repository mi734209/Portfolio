/* Name: Michael Torres
Course: CNT 4714 – Spring 2026 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: April 27, 2026
*/
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class AccountantUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 1. Verify Authentication
        HttpSession session = request.getSession(false);
        // Accepting either 'accountant' or 'theaccountant' depending on how you set it up
        if (session == null || session.getAttribute("currentUser") == null ||
                (!session.getAttribute("currentUser").equals("theaccountant") && !session.getAttribute("currentUser").equals("accountant"))) {
            response.sendRedirect(request.getContextPath() + "/Front-End-Pages/errorpage.html");
            return;
        }

        String reportType = request.getParameter("report");
        String sqlResult = "";

        // 2. Load Properties
        Properties properties = new Properties();
        String propertiesPath = getServletContext().getRealPath("/WEB-INF/conf/theaccountant.properties");

        try (FileInputStream fis = new FileInputStream(propertiesPath)) {
            properties.load(fis);
        } catch (IOException e) {
            sqlResult = "<div style='color:red;'>Error loading database properties. Make sure file is named 'theaccountant.properties'.</div>";
        }

        // 3. Connect and Execute CallableStatements
        if (reportType != null && sqlResult.isEmpty()) {
            String dbUrl = properties.getProperty("MYSQL_DB_URL");
            String dbUser = properties.getProperty("MYSQL_DB_USERNAME");
            String dbPass = properties.getProperty("MYSQL_DB_PASSWORD");

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {

                    CallableStatement cstmt = null;
                    ResultSet rs = null;

                    // Execute the specific stored procedure based on the radio button selected
                    switch (reportType) {
                        case "1":
                            cstmt = conn.prepareCall("{call Get_The_Maximum_Status_Of_All_Suppliers()}");
                            break;
                        case "2":
                            cstmt = conn.prepareCall("{call Get_The_Sum_Of_All_Parts_Weights()}");
                            break;
                        case "3":
                            cstmt = conn.prepareCall("{call Get_The_Total_Number_Of_Shipments()}");
                            break;
                        case "4":
                            cstmt = conn.prepareCall("{call Get_The_Name_Of_The_Job_With_The_Most_Workers()}");
                            break;
                        case "5":
                            cstmt = conn.prepareCall("{call List_The_Name_And_Status_Of_All_Suppliers()}");
                            break;
                    }

                    if (cstmt != null) {
                        rs = cstmt.executeQuery();
                        sqlResult = buildHtmlTableFromResult(rs);
                        rs.close();
                        cstmt.close();
                    }

                }
            } catch (SQLException e) {
                sqlResult = "<div style='background-color: red; color: white; padding: 10px; font-weight: bold; width: 80%; margin: 0 auto;'>" +
                        "Error executing the stored procedure:<br>" + e.getMessage() + "</div>";
            } catch (Exception e) {
                sqlResult = "<div style='color:red; font-weight:bold;'>System Error: " + e.getMessage() + "</div>";
            }
        }

        // 4. Return Results
        request.setAttribute("sqlResult", sqlResult);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Front-End-Pages/accountantHome.jsp");
        dispatcher.forward(request, response);
    }

    // Standard HTML Table Builder
    private String buildHtmlTableFromResult(ResultSet rs) throws SQLException {
        StringBuilder html = new StringBuilder();
        html.append("<table style='width: 100%; border-collapse: collapse; margin-top: 10px;'>");
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount();

        html.append("<tr style='background-color: red; color: black; font-weight: bold;'>");
        for (int i = 1; i <= columnCount; i++) {
            html.append("<th style='border: 1px solid white; padding: 5px;'>").append(rsmd.getColumnName(i)).append("</th>");
        }
        html.append("</tr>");

        boolean alternateColor = false;
        while (rs.next()) {
            String bgColor = alternateColor ? "#cccccc" : "#ffffff";
            html.append("<tr style='background-color: ").append(bgColor).append("; color: black;'>");
            for (int i = 1; i <= columnCount; i++) {
                html.append("<td style='border: 1px solid white; padding: 5px; text-align: center;'>").append(rs.getString(i)).append("</td>");
            }
            html.append("</tr>");
            alternateColor = !alternateColor;
        }
        html.append("</table>");
        return html.toString();
    }
}