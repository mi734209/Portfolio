<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Entry App</title>
    <style>
        body { background-color: black; color: white; font-family: sans-serif; text-align: center; }
        .header-yellow { color: yellow; font-size: 2em; margin-bottom: 10px; }
        .header-red { color: red; font-size: 1.5em; margin-bottom: 30px; }
        .user-status { color: white; font-size: 1em; margin-bottom: 20px; }
        .entry-text { color: yellow; font-weight: bold; }
        .form-section { border: 1px solid white; padding: 15px; margin: 20px auto; width: 80%; text-align: left; }
        .form-table { margin: 0 auto; border-collapse: collapse; }
        .form-table th, .form-table td { border: 2px solid yellow; padding: 5px; text-align: center; }
        .form-table input[type="text"] { background-color: #555; color: white; border: none; width: 100px; padding: 5px; }
        .btn-green { background-color: #00FF00; color: black; font-weight: bold; padding: 5px 15px; cursor: pointer; margin-top: 10px; }
        .btn-red { background-color: #FF0000; color: yellow; font-weight: bold; padding: 5px 15px; cursor: pointer; margin-top: 10px; }
        .results-section { margin-top: 30px; border-top: 1px solid white; padding-top: 20px; }
    </style>
    <script>
        function clearResults() { document.getElementById('executionResults').innerHTML = ''; }
    </script>
</head>
<body>

<h1 class="header-yellow">Welcome to the Spring 2026 Project 4 Enterprise System</h1>
<h2 class="header-red">Data Entry Application</h2>

<hr style="width: 90%; border-color: white;">

<div class="user-status">
    You are connected to the Project 4 Enterprise System database as a <span class="entry-text">data-entry-level</span> user.<br>
    Enter the data values in a form below to add a new record to the corresponding database table.
</div>

<div class="form-section">
    <legend>Suppliers Record Insert</legend>
    <form action="${pageContext.request.contextPath}/DataEntryServlet" method="POST">
        <input type="hidden" name="formType" value="supplier">
        <table class="form-table">
            <tr><th>snum</th><th>sname</th><th>status</th><th>city</th></tr>
            <tr>
                <td><input type="text" name="snum" required></td>
                <td><input type="text" name="sname" required></td>
                <td><input type="text" name="status" required></td>
                <td><input type="text" name="city" required></td>
            </tr>
        </table>
        <div style="text-align: center;">
            <input type="submit" value="Enter Supplier Record Into Database" class="btn-green">
            <input type="reset" value="Clear Data and Results" class="btn-red" onclick="clearResults()">
        </div>
    </form>
</div>

<div class="form-section">
    <legend>Parts Record Insert</legend>
    <form action="${pageContext.request.contextPath}/DataEntryServlet" method="POST">
        <input type="hidden" name="formType" value="part">
        <table class="form-table">
            <tr><th>pnum</th><th>pname</th><th>color</th><th>weight</th><th>city</th></tr>
            <tr>
                <td><input type="text" name="pnum" required></td>
                <td><input type="text" name="pname" required></td>
                <td><input type="text" name="color" required></td>
                <td><input type="text" name="weight" required></td>
                <td><input type="text" name="city" required></td>
            </tr>
        </table>
        <div style="text-align: center;">
            <input type="submit" value="Enter Part Record Into Database" class="btn-green">
            <input type="reset" value="Clear Data and Results" class="btn-red" onclick="clearResults()">
        </div>
    </form>
</div>

<div class="form-section">
    <legend>Jobs Record Insert</legend>
    <form action="${pageContext.request.contextPath}/DataEntryServlet" method="POST">
        <input type="hidden" name="formType" value="job">
        <table class="form-table">
            <tr><th>jnum</th><th>jname</th><th>numworkers</th><th>city</th></tr>
            <tr>
                <td><input type="text" name="jnum" required></td>
                <td><input type="text" name="jname" required></td>
                <td><input type="text" name="numworkers" required></td>
                <td><input type="text" name="city" required></td>
            </tr>
        </table>
        <div style="text-align: center;">
            <input type="submit" value="Enter Job Record Into Database" class="btn-green">
            <input type="reset" value="Clear Data and Results" class="btn-red" onclick="clearResults()">
        </div>
    </form>
</div>

<div class="form-section">
    <legend>Shipments Record Insert</legend>
    <form action="${pageContext.request.contextPath}/DataEntryServlet" method="POST">
        <input type="hidden" name="formType" value="shipment">
        <table class="form-table">
            <tr><th>snum</th><th>pnum</th><th>jnum</th><th>quantity</th></tr>
            <tr>
                <td><input type="text" name="snum" required></td>
                <td><input type="text" name="pnum" required></td>
                <td><input type="text" name="jnum" required></td>
                <td><input type="text" name="quantity" required></td>
            </tr>
        </table>
        <div style="text-align: center;">
            <input type="submit" value="Enter Shipment Record Into Database" class="btn-green">
            <input type="reset" value="Clear Data and Results" class="btn-red" onclick="clearResults()">
        </div>
    </form>
</div>

<div class="results-section">
    <h3>Execution Results:</h3>
    <div id="executionResults">
        ${sqlResult}
    </div>
</div>

</body>
</html>