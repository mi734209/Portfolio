<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Accountant App</title>
  <style>
    body { background-color: black; color: white; font-family: sans-serif; text-align: center; }
    .header-purple { color: #cc66ff; font-size: 2em; margin-bottom: 10px; }
    .header-cyan { color: cyan; font-size: 1.5em; margin-bottom: 30px; }
    .user-status { color: white; font-size: 1em; margin-bottom: 20px; }
    .acc-text { color: #cc66ff; font-weight: bold; }
    .form-section { border: 1px solid white; padding: 20px; margin: 20px auto; width: 60%; text-align: left; }
    .radio-group { display: flex; flex-direction: column; gap: 15px; margin-bottom: 20px; font-size: 1.2em; }
    .btn-group { text-align: center; }
    .btn-execute { background-color: #00FF00; color: black; font-weight: bold; padding: 5px 15px; cursor: pointer; margin: 0 10px; }
    .btn-clear { background-color: #FFFF00; color: black; font-weight: bold; padding: 5px 15px; cursor: pointer; margin: 0 10px; }
    .results-section { margin-top: 30px; border-top: 1px solid white; padding-top: 20px; }
  </style>
  <script>
    function clearResults() { document.getElementById('executionResults').innerHTML = ''; }
  </script>
</head>
<body>

<h1 class="header-purple">Welcome to the Spring 2026 Project 4 Enterprise System</h1>
<h2 class="header-cyan">Accountant Application</h2>

<hr style="width: 90%; border-color: white;">

<div class="user-status">
  You are connected to the Project 4 Enterprise System database as an <span class="acc-text">accountant-level</span> user.<br>
  Please select the report you would like to generate from the list below.
</div>

<div class="form-section">
  <form action="${pageContext.request.contextPath}/AccountantUserServlet" method="POST">
    <div class="radio-group">
      <label><input type="radio" name="report" value="1" required> Get The Maximum Status Value Of All Suppliers</label>
      <label><input type="radio" name="report" value="2"> Get The Total Weight Of All Parts</label>
      <label><input type="radio" name="report" value="3"> Get The Total Number of Shipments</label>
      <label><input type="radio" name="report" value="4"> Get The Name And Number Of Workers Of The Job With The Most Workers</label>
      <label><input type="radio" name="report" value="5"> List The Name And Status Of Every Supplier</label>
    </div>
    <div class="btn-group">
      <input type="submit" value="Execute Command" class="btn-execute">
      <input type="button" value="Clear Results" class="btn-clear" onclick="clearResults()">
    </div>
  </form>
</div>

<div class="results-section">
  <h3>Execution Results:</h3>
  <div id="executionResults">
    ${sqlResult}
  </div>
</div>

</body>
</html>